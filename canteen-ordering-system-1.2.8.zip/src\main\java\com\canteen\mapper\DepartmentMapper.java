package com.canteen.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.canteen.entity.Department;

/**
 * 部门Mapper接口
 */
public interface DepartmentMapper extends BaseMapper<Department> {

}
