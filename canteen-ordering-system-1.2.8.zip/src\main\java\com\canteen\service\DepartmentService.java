package com.canteen.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.canteen.entity.Department;

/**
 * 部门服务接口
 */
public interface DepartmentService extends IService<Department> {

}
