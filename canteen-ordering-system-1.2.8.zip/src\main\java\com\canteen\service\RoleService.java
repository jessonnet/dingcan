package com.canteen.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.canteen.entity.Role;

/**
 * 角色服务接口
 */
public interface RoleService extends IService<Role> {

}
