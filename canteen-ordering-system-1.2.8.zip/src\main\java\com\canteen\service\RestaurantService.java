package com.canteen.service;

import com.baomidou.mybatisplus.extension.service.IService;
import com.canteen.entity.Restaurant;

public interface RestaurantService extends IService<Restaurant> {
}
